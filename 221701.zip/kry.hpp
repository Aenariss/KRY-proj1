#ifndef KRY_H
#define KRY_H

int main(int argc, char* argv[]);

#endif
